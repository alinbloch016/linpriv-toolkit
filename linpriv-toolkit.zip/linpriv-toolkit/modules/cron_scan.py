"""
Cron Job Vulnerabilities
Enumerates system-wide cron entries and flags any that execute a
script writable by non-root users -- the classic "wait for root's
cron to run my modified script" escalation.
"""

import os
import re
from .common import Finding, Severity, run_cmd

CRON_LOCATIONS = ["/etc/crontab", "/etc/cron.d"]
CRON_DIRS = ["/etc/cron.hourly", "/etc/cron.daily", "/etc/cron.weekly", "/etc/cron.monthly"]


def _is_writable_by_others(path):
    try:
        st = os.stat(path)
        mode = oct(st.st_mode)[-3:]
        return (int(mode[1]) & 2) or (int(mode[2]) & 2)
    except Exception:
        return False


def _extract_script_paths(line):
    # crude but effective: pull anything that looks like an absolute path
    return re.findall(r"(/[\w./-]+)", line)


def scan():
    findings = []
    writable_targets = []
    raw_entries = []

    # /etc/crontab and /etc/cron.d/*
    for loc in CRON_LOCATIONS:
        if os.path.isfile(loc):
            content, _, _ = run_cmd(f"cat {loc} 2>/dev/null")
            raw_entries.append((loc, content))
        elif os.path.isdir(loc):
            listing, _, _ = run_cmd(f"ls -1 {loc} 2>/dev/null")
            for fname in listing.splitlines():
                fpath = f"{loc}/{fname}"
                content, _, _ = run_cmd(f"cat {fpath} 2>/dev/null")
                raw_entries.append((fpath, content))

    # cron.hourly/daily/weekly/monthly script directories
    for d in CRON_DIRS:
        listing, _, _ = run_cmd(f"ls -1 {d} 2>/dev/null")
        for fname in listing.splitlines():
            if not fname.strip():
                continue
            fpath = f"{d}/{fname}"
            if _is_writable_by_others(fpath):
                writable_targets.append(fpath)

    # scan parsed crontab lines for referenced script paths
    for source, content in raw_entries:
        for line in content.splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            for path in _extract_script_paths(line):
                if os.path.isfile(path) and _is_writable_by_others(path):
                    writable_targets.append(path)

    writable_targets = sorted(set(writable_targets))

    if writable_targets:
        findings.append(Finding(
            module="Cron",
            title=f"{len(writable_targets)} cron-executed script(s) writable by non-root",
            detail=(
                "These scripts are referenced by system cron jobs (which run as "
                "root) and can be modified by non-root users:\n" +
                "\n".join(f"  - {p}" for p in writable_targets)
            ),
            severity=Severity.CRITICAL,
            exploitability=(
                "Replacing the script content with attacker-controlled commands "
                "will result in root code execution the next time cron fires."
            ),
            mitigation="Restrict write access to root only: chown root:root <path>; chmod o-w,g-w <path>.",
            evidence="\n".join(writable_targets),
        ))
    else:
        findings.append(Finding(
            module="Cron",
            title="No writable root-cron scripts found",
            detail="Checked /etc/crontab, /etc/cron.d, and cron.{hourly,daily,weekly,monthly}.",
            severity=Severity.INFO,
            exploitability="N/A",
            mitigation="N/A",
        ))

    if raw_entries:
        findings.append(Finding(
            module="Cron",
            title="Cron entry inventory",
            detail="Raw cron entries collected for manual review.",
            severity=Severity.INFO,
            exploitability="N/A -- informational.",
            mitigation="N/A",
            evidence="\n\n".join(f"--- {src} ---\n{content}" for src, content in raw_entries),
        ))

    return findings
