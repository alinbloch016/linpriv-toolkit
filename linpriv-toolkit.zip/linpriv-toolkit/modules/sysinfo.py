"""
STEP 1: System Information Collection
Gathers baseline context: current user, groups, kernel, OS release,
and whether we're already root (in which case privesc scanning is moot).
"""

import os
import getpass
from .common import run_cmd

try:
    import pwd
except ImportError:
    pwd = None  # not available on non-POSIX platforms; gather() falls back below


def gather():
    info = {}

    uid = os.getuid() if hasattr(os, "getuid") else -1
    if pwd is not None:
        try:
            info["username"] = pwd.getpwuid(uid).pw_name
        except KeyError:
            info["username"] = getpass.getuser()
    else:
        info["username"] = getpass.getuser()
    info["uid"] = uid
    info["is_root"] = uid == 0

    groups_out, _, _ = run_cmd("id")
    info["id_output"] = groups_out

    kernel_out, _, _ = run_cmd("uname -a")
    info["kernel"] = kernel_out

    os_release, _, rc = run_cmd("cat /etc/os-release")
    info["os_release"] = os_release if rc == 0 else "unavailable"

    hostname, _, _ = run_cmd("hostname")
    info["hostname"] = hostname

    return info


def print_summary(info):
    print("=" * 60)
    print("SYSTEM INFORMATION")
    print("=" * 60)
    print(f"User        : {info['username']} (uid={info['uid']})")
    print(f"Root?       : {'YES' if info['is_root'] else 'no'}")
    print(f"Hostname    : {info['hostname']}")
    print(f"Kernel      : {info['kernel']}")
    print("-" * 60)
    if info["is_root"]:
        print("NOTE: Already running as root -- privilege escalation scanning")
        print("      is not applicable, but checks will still run for auditing")
        print("      purposes (e.g. to find vectors OTHER users could abuse).")
    print()
