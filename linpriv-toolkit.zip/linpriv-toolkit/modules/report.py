"""
STEP 4: Report Generation
Turns the collected list of Finding objects into:
  - a console summary
  - a plain-text report file
  - an HTML report file (styled, easy to screenshot/attach)
"""

import html
import json
from datetime import datetime
from .common import Severity


def _sorted_findings(findings):
    return sorted(findings, key=lambda f: Severity.ORDER.get(f.severity, 99))


def print_console_summary(findings):
    findings = _sorted_findings(findings)
    counts = {}
    for f in findings:
        counts[f.severity] = counts.get(f.severity, 0) + 1

    print("=" * 60)
    print("SCAN SUMMARY")
    print("=" * 60)
    for sev in [Severity.CRITICAL, Severity.HIGH, Severity.MEDIUM, Severity.LOW, Severity.INFO]:
        if sev in counts:
            print(f"  {sev:<10}: {counts[sev]}")
    print("=" * 60)
    print()

    for f in findings:
        if f.severity == Severity.INFO:
            continue  # keep console output focused on actionable findings
        print(f"[{f.severity}] ({f.module}) {f.title}")
        print(f"  Detail        : {f.detail.splitlines()[0]}")
        print(f"  Exploitability: {f.exploitability}")
        print(f"  Mitigation    : {f.mitigation}")
        print()


def write_text_report(findings, sysinfo, path):
    findings = _sorted_findings(findings)
    lines = []
    lines.append("LINUX PRIVILEGE ESCALATION AUDIT REPORT")
    lines.append(f"Generated: {datetime.now().isoformat()}")
    lines.append(f"Host: {sysinfo.get('hostname', 'unknown')}")
    lines.append(f"User: {sysinfo.get('username', 'unknown')} (uid={sysinfo.get('uid')})")
    lines.append(f"Kernel: {sysinfo.get('kernel', 'unknown')}")
    lines.append("=" * 70)
    lines.append("")

    for f in findings:
        lines.append(f"[{f.severity}] {f.title}")
        lines.append(f"Module        : {f.module}")
        lines.append(f"Detail        : {f.detail}")
        lines.append(f"Exploitability: {f.exploitability}")
        lines.append(f"Mitigation    : {f.mitigation}")
        if f.evidence:
            lines.append(f"Evidence      :\n{f.evidence}")
        lines.append("-" * 70)

    with open(path, "w") as fh:
        fh.write("\n".join(lines))


SEVERITY_COLORS = {
    "CRITICAL": "#7a0d0d",
    "HIGH": "#c0392b",
    "MEDIUM": "#d68910",
    "LOW": "#2e7d32",
    "INFO": "#5b6b73",
}


def write_html_report(findings, sysinfo, path):
    findings = _sorted_findings(findings)
    counts = {}
    for f in findings:
        counts[f.severity] = counts.get(f.severity, 0) + 1

    def esc(s):
        return html.escape(str(s)) if s else ""

    rows = []
    for f in findings:
        color = SEVERITY_COLORS.get(f.severity, "#333")
        evidence_html = f"<pre class='evidence'>{esc(f.evidence)}</pre>" if f.evidence else ""
        rows.append(f"""
        <div class="finding" style="border-left: 5px solid {color};">
          <div class="finding-header">
            <span class="badge" style="background:{color};">{esc(f.severity)}</span>
            <span class="module">{esc(f.module)}</span>
            <h3>{esc(f.title)}</h3>
          </div>
          <p><strong>Detail:</strong> {esc(f.detail).replace(chr(10), '<br>')}</p>
          <p><strong>Exploitability:</strong> {esc(f.exploitability)}</p>
          <p><strong>Mitigation:</strong> {esc(f.mitigation)}</p>
          {evidence_html}
        </div>
        """)

    summary_badges = "".join(
        f"<span class='summary-badge' style='background:{SEVERITY_COLORS.get(sev,'#333')}'>"
        f"{sev}: {counts.get(sev,0)}</span>"
        for sev in [Severity.CRITICAL, Severity.HIGH, Severity.MEDIUM, Severity.LOW, Severity.INFO]
    )

    html_doc = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Linux Privilege Escalation Audit Report</title>
<style>
  body {{ font-family: -apple-system, Segoe UI, Roboto, sans-serif; background:#f4f5f7; margin:0; padding:2rem; color:#1c1c1c; }}
  .header {{ background:#1c2b36; color:white; padding:1.5rem 2rem; border-radius:8px; margin-bottom:1.5rem; }}
  .header h1 {{ margin:0 0 .5rem 0; font-size:1.4rem; }}
  .header p {{ margin:.15rem 0; font-size:.9rem; opacity:.85; }}
  .summary {{ margin-bottom:1.5rem; }}
  .summary-badge {{ display:inline-block; color:white; padding:.3rem .7rem; border-radius:4px; margin-right:.5rem; font-size:.85rem; font-weight:600; }}
  .finding {{ background:white; padding:1rem 1.2rem; margin-bottom:1rem; border-radius:6px; box-shadow:0 1px 3px rgba(0,0,0,.08); }}
  .finding-header {{ display:flex; align-items:center; gap:.6rem; flex-wrap:wrap; margin-bottom:.5rem; }}
  .finding-header h3 {{ margin:0; font-size:1rem; flex-basis:100%; margin-top:.3rem; }}
  .badge {{ color:white; padding:.15rem .5rem; border-radius:4px; font-size:.75rem; font-weight:700; }}
  .module {{ font-size:.8rem; color:#666; font-weight:600; text-transform:uppercase; letter-spacing:.03em; }}
  p {{ font-size:.9rem; line-height:1.4; margin:.35rem 0; }}
  .evidence {{ background:#f0f0f0; padding:.6rem; border-radius:4px; font-size:.78rem; overflow-x:auto; white-space:pre-wrap; word-break:break-all; }}
</style>
</head>
<body>
  <div class="header">
    <h1>Linux Privilege Escalation Audit Report</h1>
    <p>Generated: {esc(datetime.now().isoformat())}</p>
    <p>Host: {esc(sysinfo.get('hostname'))} &nbsp;|&nbsp; User: {esc(sysinfo.get('username'))} (uid={esc(str(sysinfo.get('uid')))})</p>
    <p>Kernel: {esc(sysinfo.get('kernel'))}</p>
  </div>
  <div class="summary">{summary_badges}</div>
  {''.join(rows)}
</body>
</html>
"""
    with open(path, "w") as fh:
        fh.write(html_doc)


def write_json_report(findings, sysinfo, path):
    """Machine-readable output -- for feeding into CI pipelines, SIEMs, etc."""
    findings = _sorted_findings(findings)
    counts = {}
    for f in findings:
        counts[f.severity] = counts.get(f.severity, 0) + 1

    doc = {
        "generated": datetime.now().isoformat(),
        "host": sysinfo.get("hostname"),
        "user": sysinfo.get("username"),
        "uid": sysinfo.get("uid"),
        "kernel": sysinfo.get("kernel"),
        "summary": counts,
        "findings": [f.to_dict() for f in findings],
    }
    with open(path, "w") as fh:
        json.dump(doc, fh, indent=2)
