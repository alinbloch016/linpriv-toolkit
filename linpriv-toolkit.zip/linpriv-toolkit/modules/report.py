"""
STEP 4: Report Generation
Turns the collected list of Finding objects (plus an optional risk
score from modules.scoring) into:
  - a plain-text report file
  - an HTML report file (styled, easy to screenshot/attach)
  - a JSON report file (machine-readable, for CI/SIEM ingestion)
"""

import html
import json
from datetime import datetime
from .common import Severity

SEVERITY_ORDER_LIST = [Severity.CRITICAL, Severity.HIGH, Severity.MEDIUM, Severity.LOW, Severity.INFO]


def _sorted_findings(findings):
    return sorted(findings, key=lambda f: Severity.ORDER.get(f.severity, 99))


def _counts(findings):
    counts = {}
    for f in findings:
        counts[f.severity] = counts.get(f.severity, 0) + 1
    return counts


def write_text_report(findings, sysinfo, path, score_data=None):
    findings = _sorted_findings(findings)
    counts = _counts(findings)
    lines = []
    lines.append("LINUX PRIVILEGE ESCALATION AUDIT REPORT")
    lines.append(f"Generated: {datetime.now().isoformat()}")
    lines.append(f"Host: {sysinfo.get('hostname', 'unknown')}")
    lines.append(f"User: {sysinfo.get('username', 'unknown')} (uid={sysinfo.get('uid')})")
    lines.append(f"Kernel: {sysinfo.get('kernel', 'unknown')}")
    if score_data:
        lines.append(
            f"Security Posture Score: {score_data['score']}/100 "
            f"(grade {score_data['grade']} -- {score_data['grade_label']})"
        )
    lines.append("=" * 70)
    lines.append("SUMMARY")
    for sev in SEVERITY_ORDER_LIST:
        if sev in counts:
            lines.append(f"  {sev:<10}: {counts[sev]}")
    lines.append("=" * 70)
    lines.append("")

    for f in findings:
        lines.append(f"[{f.severity}] {f.title}")
        lines.append(f"Module        : {f.module}")
        lines.append(f"Detail        : {f.detail}")
        lines.append(f"Exploitability: {f.exploitability}")
        lines.append(f"Mitigation    : {f.mitigation}")
        if f.evidence:
            lines.append(f"Evidence      :\n{f.evidence}")
        lines.append("-" * 70)

    with open(path, "w") as fh:
        fh.write("\n".join(lines))


SEVERITY_COLORS = {
    "CRITICAL": "#7a0d0d",
    "HIGH": "#c0392b",
    "MEDIUM": "#d68910",
    "LOW": "#2e7d32",
    "INFO": "#5b6b73",
}

GRADE_COLORS = {"A": "#1e7d32", "B": "#4caf50", "C": "#d68910", "D": "#c0392b", "F": "#7a0d0d"}


def write_html_report(findings, sysinfo, path, score_data=None):
    findings = _sorted_findings(findings)
    counts = _counts(findings)

    def esc(s):
        return html.escape(str(s)) if s else ""

    rows = []
    for f in findings:
        color = SEVERITY_COLORS.get(f.severity, "#333")
        evidence_html = f"<pre class='evidence'>{esc(f.evidence)}</pre>" if f.evidence else ""
        rows.append(f"""
        <div class="finding" style="border-left: 5px solid {color};">
          <div class="finding-header">
            <span class="badge" style="background:{color};">{esc(f.severity)}</span>
            <span class="module">{esc(f.module)}</span>
            <h3>{esc(f.title)}</h3>
          </div>
          <p><strong>Detail:</strong> {esc(f.detail).replace(chr(10), '<br>')}</p>
          <p><strong>Exploitability:</strong> {esc(f.exploitability)}</p>
          <p><strong>Mitigation:</strong> {esc(f.mitigation)}</p>
          {evidence_html}
        </div>
        """)

    summary_badges = "".join(
        f"<span class='summary-badge' style='background:{SEVERITY_COLORS.get(sev,'#333')}'>"
        f"{sev}: {counts.get(sev,0)}</span>"
        for sev in SEVERITY_ORDER_LIST
    )

    score_block = ""
    if score_data:
        grade_color = GRADE_COLORS.get(score_data["grade"], "#333")
        score_block = f"""
        <div class="score-card" style="border-left: 6px solid {grade_color};">
          <div class="score-number" style="color:{grade_color};">{esc(score_data['score'])}<span class="score-max">/100</span></div>
          <div class="score-grade" style="background:{grade_color};">{esc(score_data['grade'])}</div>
          <div class="score-label">{esc(score_data['grade_label'])}</div>
        </div>
        """

    html_doc = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Linux Privilege Escalation Audit Report</title>
<style>
  body {{ font-family: -apple-system, Segoe UI, Roboto, sans-serif; background:#f4f5f7; margin:0; padding:2rem; color:#1c1c1c; }}
  .header {{ background:#1c2b36; color:white; padding:1.5rem 2rem; border-radius:8px; margin-bottom:1.5rem; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:1rem; }}
  .header h1 {{ margin:0 0 .5rem 0; font-size:1.4rem; }}
  .header p {{ margin:.15rem 0; font-size:.9rem; opacity:.85; }}
  .score-card {{ background:white; border-radius:8px; padding:.8rem 1.4rem; display:flex; align-items:center; gap:.9rem; color:#1c1c1c; }}
  .score-number {{ font-size:2rem; font-weight:800; line-height:1; }}
  .score-max {{ font-size:1rem; font-weight:400; opacity:.6; }}
  .score-grade {{ color:white; font-weight:800; border-radius:6px; width:2rem; height:2rem; display:flex; align-items:center; justify-content:center; font-size:1.1rem; }}
  .score-label {{ font-size:.85rem; color:#555; max-width:12rem; }}
  .summary {{ margin-bottom:1.5rem; }}
  .summary-badge {{ display:inline-block; color:white; padding:.3rem .7rem; border-radius:4px; margin-right:.5rem; font-size:.85rem; font-weight:600; }}
  .finding {{ background:white; padding:1rem 1.2rem; margin-bottom:1rem; border-radius:6px; box-shadow:0 1px 3px rgba(0,0,0,.08); }}
  .finding-header {{ display:flex; align-items:center; gap:.6rem; flex-wrap:wrap; margin-bottom:.5rem; }}
  .finding-header h3 {{ margin:0; font-size:1rem; flex-basis:100%; margin-top:.3rem; }}
  .badge {{ color:white; padding:.15rem .5rem; border-radius:4px; font-size:.75rem; font-weight:700; }}
  .module {{ font-size:.8rem; color:#666; font-weight:600; text-transform:uppercase; letter-spacing:.03em; }}
  p {{ font-size:.9rem; line-height:1.4; margin:.35rem 0; }}
  .evidence {{ background:#f0f0f0; padding:.6rem; border-radius:4px; font-size:.78rem; overflow-x:auto; white-space:pre-wrap; word-break:break-all; }}
  footer {{ text-align:center; font-size:.75rem; color:#888; margin-top:2rem; }}
</style>
</head>
<body>
  <div class="header">
    <div>
      <h1>Linux Privilege Escalation Audit Report</h1>
      <p>Generated: {esc(datetime.now().isoformat())}</p>
      <p>Host: {esc(sysinfo.get('hostname'))} &nbsp;|&nbsp; User: {esc(sysinfo.get('username'))} (uid={esc(str(sysinfo.get('uid')))})</p>
      <p>Kernel: {esc(sysinfo.get('kernel'))}</p>
    </div>
    {score_block}
  </div>
  <div class="summary">{summary_badges}</div>
  {''.join(rows)}
  <footer>Detection-only audit -- no exploit code was executed against this host.</footer>
</body>
</html>
"""
    with open(path, "w") as fh:
        fh.write(html_doc)


def write_json_report(findings, sysinfo, path, score_data=None):
    """Machine-readable output -- for feeding into CI pipelines, SIEMs, etc."""
    findings = _sorted_findings(findings)
    counts = _counts(findings)

    doc = {
        "generated": datetime.now().isoformat(),
        "host": sysinfo.get("hostname"),
        "user": sysinfo.get("username"),
        "uid": sysinfo.get("uid"),
        "kernel": sysinfo.get("kernel"),
        "score": score_data if score_data else None,
        "summary": counts,
        "findings": [f.to_dict() for f in findings],
    }
    with open(path, "w") as fh:
        json.dump(doc, fh, indent=2)
