"""
Shared utilities: the Finding data structure, subprocess helper,
and severity constants used by every scan module.
"""

import subprocess
from dataclasses import dataclass, field
from typing import Optional


class Severity:
    INFO = "INFO"
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"

    # Sort order for reports (highest risk first)
    ORDER = {CRITICAL: 0, HIGH: 1, MEDIUM: 2, LOW: 3, INFO: 4}


@dataclass
class Finding:
    module: str                 # e.g. "SUID/SGID"
    title: str                  # short summary, e.g. "Writable root cron script"
    detail: str                 # full explanation of what was found
    severity: str                # Severity.*
    exploitability: str          # short note: how this could plausibly be abused
    mitigation: str              # how to fix it
    evidence: Optional[str] = field(default=None)  # command output / path / etc.

    def to_dict(self):
        return {
            "module": self.module,
            "title": self.title,
            "detail": self.detail,
            "severity": self.severity,
            "exploitability": self.exploitability,
            "mitigation": self.mitigation,
            "evidence": self.evidence,
        }


def run_cmd(cmd, timeout=30):
    """
    Run a read-only shell command and return (stdout, stderr, returncode).
    Never raises on non-zero exit -- callers check returncode themselves.
    This toolkit only ever calls informational/listing commands
    (find, ls, systemctl status/show, sudo -l, crontab -l, uname, getcap).
    It never calls anything that modifies state or executes an exploit.
    """
    try:
        proc = subprocess.run(
            cmd,
            shell=isinstance(cmd, str),
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        return proc.stdout.strip(), proc.stderr.strip(), proc.returncode
    except subprocess.TimeoutExpired:
        return "", f"Command timed out: {cmd}", -1
    except FileNotFoundError:
        return "", f"Command not found: {cmd}", -1
    except Exception as e:
        return "", f"Error running command: {e}", -1
