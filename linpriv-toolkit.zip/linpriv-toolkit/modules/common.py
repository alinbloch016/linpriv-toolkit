"""
Shared utilities: the Finding data structure, subprocess helper,
severity constants, and logging setup used by every scan module.
"""

import logging
import subprocess
from dataclasses import dataclass, field
from typing import Optional

logger = logging.getLogger("linpriv")


def setup_logging(verbosity=0, log_file=None):
    """
    verbosity: 0 = warnings only, 1 = info (-v), 2 = debug (-vv)
    """
    level = logging.WARNING
    if verbosity == 1:
        level = logging.INFO
    elif verbosity >= 2:
        level = logging.DEBUG

    handlers = []
    if log_file:
        fh = logging.FileHandler(log_file)
        fh.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s"))
        handlers.append(fh)

    logging.basicConfig(level=level, handlers=handlers if handlers else None,
                         format="[%(levelname)s] %(message)s")
    logger.setLevel(level)
    return logger


class Severity:
    INFO = "INFO"
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"

    # Sort order for reports (highest risk first)
    ORDER = {CRITICAL: 0, HIGH: 1, MEDIUM: 2, LOW: 3, INFO: 4}


@dataclass
class Finding:
    module: str                 # e.g. "SUID/SGID"
    title: str                  # short summary, e.g. "Writable root cron script"
    detail: str                 # full explanation of what was found
    severity: str                # Severity.*
    exploitability: str          # short note: how this could plausibly be abused
    mitigation: str              # how to fix it
    evidence: Optional[str] = field(default=None)  # command output / path / etc.

    def to_dict(self):
        return {
            "module": self.module,
            "title": self.title,
            "detail": self.detail,
            "severity": self.severity,
            "exploitability": self.exploitability,
            "mitigation": self.mitigation,
            "evidence": self.evidence,
        }


def run_cmd(cmd, timeout=30):
    """
    Run a read-only shell command and return (stdout, stderr, returncode).
    Never raises on non-zero exit -- callers check returncode themselves.
    This toolkit only ever calls informational/listing commands
    (find, ls, systemctl status/show, sudo -l, crontab -l, uname, getcap).
    It never calls anything that modifies state or executes an exploit.
    """
    logger.debug("run_cmd: %s", cmd)
    try:
        proc = subprocess.run(
            cmd,
            shell=isinstance(cmd, str),
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        if proc.returncode != 0:
            logger.debug("run_cmd non-zero exit (%s): %s | stderr: %s", proc.returncode, cmd, proc.stderr.strip()[:200])
        return proc.stdout.strip(), proc.stderr.strip(), proc.returncode
    except subprocess.TimeoutExpired:
        logger.warning("Command timed out after %ss: %s", timeout, cmd)
        return "", f"Command timed out: {cmd}", -1
    except FileNotFoundError:
        logger.debug("Command not found: %s", cmd)
        return "", f"Command not found: {cmd}", -1
    except Exception as e:
        logger.warning("Error running command '%s': %s", cmd, e)
        return "", f"Error running command: {e}", -1


def build_find_excludes(exclude_paths):
    """Turn a list of paths into `find`-compatible -not -path clauses."""
    if not exclude_paths:
        return ""
    return " ".join(f"-not -path '{p}/*' -not -path '{p}'" for p in exclude_paths)
