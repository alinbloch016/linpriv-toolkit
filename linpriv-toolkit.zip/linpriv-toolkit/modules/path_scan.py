"""
PATH Hijacking Detection
If a directory earlier in $PATH than the legitimate one is writable by
the current user, and a root-run script/service calls a command by
name (not absolute path) with that PATH in effect, an attacker can
plant a malicious binary that gets executed instead.

We check two things:
  1. Directories in the *current* PATH that are writable by non-root.
  2. root's crontab / service files that reference commands by bare
     name (no leading /) -- these are the ones actually at risk if
     writable PATH dirs exist upstream of the real binary.
"""

import os
from .common import Finding, Severity, run_cmd


def _is_writable_by_others(path):
    try:
        st = os.stat(path)
        mode = oct(st.st_mode)[-3:]
        return (int(mode[1]) & 2) or (int(mode[2]) & 2)
    except Exception:
        return False


def scan():
    findings = []

    path_env = os.environ.get("PATH", "")
    dirs = [d for d in path_env.split(":") if d]

    writable_dirs = []
    for d in dirs:
        if os.path.isdir(d) and _is_writable_by_others(d):
            writable_dirs.append(d)

    # Also flag "." or empty entries in PATH, a classic misconfiguration
    relative_entries = [d for d in dirs if d in ("", ".", "./")]

    if writable_dirs:
        findings.append(Finding(
            module="PATH Hijacking",
            title=f"{len(writable_dirs)} writable director(y/ies) found in PATH",
            detail=(
                "The following directories appear in $PATH and are writable "
                "by the current (non-root) user:\n" +
                "\n".join(f"  - {d}" for d in writable_dirs) +
                "\n\nIf any of these directories come BEFORE the legitimate "
                "binary's directory in PATH, and a privileged process (root "
                "cron job, root service, SUID binary) invokes a command by "
                "bare name relying on this PATH, an attacker can plant a "
                "malicious binary of that name to hijack execution."
            ),
            severity=Severity.MEDIUM,
            exploitability=(
                "Confirm order in PATH and check whether any root-run script "
                "calls commands without an absolute path (see cron/service "
                "findings). If so, this becomes a direct root path."
            ),
            mitigation="Remove write access for non-owners on these directories, or remove them from PATH.",
            evidence="\n".join(writable_dirs),
        ))

    if relative_entries:
        findings.append(Finding(
            module="PATH Hijacking",
            title="Relative/empty entry found in PATH",
            detail=(
                "PATH contains a relative or empty entry (interpreted as the "
                "current working directory). Running any command while cwd is "
                "attacker-controlled could execute a planted binary."
            ),
            severity=Severity.MEDIUM,
            exploitability="Depends on cwd at time of execution for the affected process.",
            mitigation="Remove '.', empty, or relative entries from PATH.",
        ))

    if not writable_dirs and not relative_entries:
        findings.append(Finding(
            module="PATH Hijacking",
            title="No writable or relative directories found in current PATH",
            detail=f"Checked PATH: {path_env}",
            severity=Severity.INFO,
            exploitability="N/A",
            mitigation="N/A",
        ))

    return findings
