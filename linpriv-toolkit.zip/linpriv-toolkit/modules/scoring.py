"""
Risk Scoring Engine
Turns a flat list of Findings into a single aggregate posture score
(0-100, higher is better) and a letter grade, the way commercial
security-posture tools (Qualys, Lynis, etc.) summarize an audit for
someone who wants the headline before the detail.

This is a heuristic, not a certified scoring standard -- it's meant to
give a fast, defensible "how bad is this" signal and a sortable number
for tracking posture over repeated scans of the same host.
"""

from .common import Severity

# Points deducted per finding at each severity. Diminishing marginal
# deduction per additional finding of the same severity so that e.g.
# 20 duplicate LOW findings don't swamp the score.
SEVERITY_WEIGHT = {
    Severity.CRITICAL: 25,
    Severity.HIGH: 14,
    Severity.MEDIUM: 6,
    Severity.LOW: 2,
    Severity.INFO: 0,
}

GRADE_THRESHOLDS = [
    (90, "A", "Strong posture -- no major issues found."),
    (75, "B", "Good posture -- minor issues worth addressing."),
    (60, "C", "Moderate risk -- several issues need attention."),
    (40, "D", "Poor posture -- significant escalation paths present."),
    (0,  "F", "Critical risk -- direct root escalation path(s) found."),
]


def compute_score(findings):
    """
    Returns a dict: {score, grade, grade_label, deductions_by_severity}
    """
    counts = {}
    for f in findings:
        counts[f.severity] = counts.get(f.severity, 0) + 1

    total_deduction = 0
    deductions_by_severity = {}
    for sev, weight in SEVERITY_WEIGHT.items():
        n = counts.get(sev, 0)
        if n == 0 or weight == 0:
            deductions_by_severity[sev] = 0
            continue
        # diminishing returns: 1st finding costs full weight, each
        # subsequent one costs progressively less (sqrt-ish curve)
        deduction = sum(weight / (i ** 0.5) for i in range(1, n + 1))
        deduction = round(deduction)
        deductions_by_severity[sev] = deduction
        total_deduction += deduction

    score = max(0, 100 - total_deduction)

    grade, grade_label = "F", GRADE_THRESHOLDS[-1][2]
    for threshold, letter, label in GRADE_THRESHOLDS:
        if score >= threshold:
            grade, grade_label = letter, label
            break

    return {
        "score": score,
        "grade": grade,
        "grade_label": grade_label,
        "deductions_by_severity": deductions_by_severity,
        "counts_by_severity": counts,
    }


def worst_severity(findings):
    """Highest severity present, for exit-code / fail_on decisions."""
    order = [Severity.CRITICAL, Severity.HIGH, Severity.MEDIUM, Severity.LOW, Severity.INFO]
    present = {f.severity for f in findings}
    for sev in order:
        if sev in present:
            return sev
    return None
