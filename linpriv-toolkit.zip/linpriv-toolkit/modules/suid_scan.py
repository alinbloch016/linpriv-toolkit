"""
SUID/SGID Binary Discovery
Scans the filesystem for binaries with the SUID or SGID bit set,
and flags any that appear on the well-known GTFOBins-style
"dangerous if SUID" list -- these are binaries known to allow
shell/file-read/file-write breakout when run with elevated bits.

This module only *lists* matches. It does not invoke the binaries
or attempt to use them to escalate privileges.
"""

from .common import Finding, Severity, run_cmd

# Binaries commonly documented (via GTFOBins) as dangerous when SUID.
# This is a detection reference list only.
KNOWN_DANGEROUS_SUID = {
    "awk", "find", "vim", "vi", "nano", "less", "more", "perl", "python",
    "python3", "ruby", "php", "nmap", "cp", "mv", "bash", "sh", "env",
    "tar", "zip", "unzip", "rsync", "ftp", "curl", "wget", "docker",
    "git", "gdb", "strace", "socat", "xxd", "openssl", "scp", "ssh",
    "make", "node", "lua", "gcc", "cc",
}


def scan():
    findings = []

    # -perm -4000 = SUID, -perm -2000 = SGID
    suid_out, _, _ = run_cmd(
        "find / -xdev -perm -4000 -type f 2>/dev/null"
    )
    sgid_out, _, _ = run_cmd(
        "find / -xdev -perm -2000 -type f 2>/dev/null"
    )

    suid_files = [l for l in suid_out.splitlines() if l.strip()]
    sgid_files = [l for l in sgid_out.splitlines() if l.strip()]

    dangerous_hits = []
    for path in suid_files + sgid_files:
        binary_name = path.rsplit("/", 1)[-1]
        if binary_name in KNOWN_DANGEROUS_SUID:
            dangerous_hits.append(path)

    if dangerous_hits:
        findings.append(Finding(
            module="SUID/SGID",
            title=f"{len(dangerous_hits)} known-risky SUID/SGID binaries found",
            detail=(
                "The following binaries have the SUID or SGID bit set and are "
                "documented (e.g. in GTFOBins) as capable of spawning a shell, "
                "reading arbitrary files, or writing arbitrary files when run "
                "with elevated privileges:\n" + "\n".join(f"  - {p}" for p in dangerous_hits)
            ),
            severity=Severity.HIGH,
            exploitability=(
                "If these bits were set deliberately for a legitimate reason, "
                "review GTFOBins for the specific binary to see the documented "
                "abuse technique. If unintentional, this is a direct root path."
            ),
            mitigation=(
                "Remove the SUID/SGID bit unless strictly required: "
                "chmod u-s,g-s <path>. If required, restrict execution to a "
                "trusted group and audit why the bit is set."
            ),
            evidence="\n".join(dangerous_hits),
        ))

    if suid_files or sgid_files:
        findings.append(Finding(
            module="SUID/SGID",
            title=f"Full SUID/SGID inventory ({len(suid_files)} SUID, {len(sgid_files)} SGID)",
            detail="Complete list of all SUID/SGID binaries found, for manual review.",
            severity=Severity.INFO,
            exploitability="N/A -- informational inventory.",
            mitigation="Review against your baseline; investigate anything unexpected.",
            evidence="SUID:\n" + "\n".join(suid_files) + "\n\nSGID:\n" + "\n".join(sgid_files),
        ))

    return findings
