"""
Configuration loading.
Supports an optional YAML config file (default search path:
./linpriv.yml or ~/.config/linpriv/config.yml) so users don't have to
pass the same flags every run, and so filesystem scans can exclude
noisy paths (network mounts, huge archive directories, etc.) without
editing source.

Precedence: CLI flags > config file > built-in defaults.
"""

import os

try:
    import yaml
    HAVE_YAML = True
except ImportError:
    HAVE_YAML = False

DEFAULT_CONFIG = {
    "modules": "all",
    "out_dir": "./report_output",
    "exclude_paths": ["/proc", "/sys", "/dev", "/tmp"],
    "fail_on": "high",   # exit non-zero if any finding >= this severity: critical|high|medium|low|none
    "show_info": False,
}

SEARCH_PATHS = [
    "./linpriv.yml",
    "./linpriv.yaml",
    os.path.expanduser("~/.config/linpriv/config.yml"),
]


def load_config(explicit_path=None):
    """
    Returns (config_dict, source_path_or_None, warning_or_None).
    Never raises -- falls back to defaults on any error so a bad/missing
    config file never blocks a scan.
    """
    config = dict(DEFAULT_CONFIG)

    if not HAVE_YAML:
        if explicit_path:
            return config, None, "PyYAML not installed -- ignoring --config; run: pip install pyyaml"
        return config, None, None

    candidates = [explicit_path] if explicit_path else SEARCH_PATHS
    for path in candidates:
        if path and os.path.isfile(path):
            try:
                with open(path) as fh:
                    user_cfg = yaml.safe_load(fh) or {}
                config.update({k: v for k, v in user_cfg.items() if k in DEFAULT_CONFIG})
                return config, path, None
            except Exception as e:
                return config, None, f"Failed to parse config '{path}': {e}"

    if explicit_path:
        return config, None, f"Config file not found: {explicit_path}"

    return config, None, None
