"""
Misconfigured Services & Sudo Rules
- systemd services running as root that point to user-writable ExecStart paths
- insecure PATH entries in service environment
- sudo -l output, flagging NOPASSWD and dangerous ALL=(ALL) rules
"""

import os
import re
from .common import Finding, Severity, run_cmd


def _is_writable_by_others(path):
    try:
        st = os.stat(path)
        mode = oct(st.st_mode)[-3:]
        return (int(mode[1]) & 2) or (int(mode[2]) & 2)
    except Exception:
        return False


def scan_services():
    findings = []

    units_out, _, _ = run_cmd(
        "systemctl list-units --type=service --state=running --no-legend --no-pager 2>/dev/null"
    )
    service_names = [line.split()[0] for line in units_out.splitlines() if line.strip()]

    risky_services = []
    for svc in service_names:
        show_out, _, _ = run_cmd(f"systemctl show {svc} -p ExecStart -p User -p Environment 2>/dev/null")
        exec_match = re.search(r"path=([^\s;]+)", show_out)
        user_match = re.search(r"User=(\S*)", show_out)
        runs_as_root = (not user_match) or user_match.group(1) in ("", "root")

        if exec_match and runs_as_root:
            exec_path = exec_match.group(1)
            if os.path.exists(exec_path) and _is_writable_by_others(exec_path):
                risky_services.append((svc, exec_path))

    if risky_services:
        findings.append(Finding(
            module="Services",
            title=f"{len(risky_services)} root service(s) with writable ExecStart target",
            detail=(
                "These systemd services run as root and their ExecStart binary "
                "is writable by non-root users:\n" +
                "\n".join(f"  - {s} -> {p}" for s, p in risky_services)
            ),
            severity=Severity.CRITICAL,
            exploitability=(
                "Overwriting the target binary and restarting/waiting for the "
                "service to run would execute attacker code as root."
            ),
            mitigation="Restrict write access on the binary to root only; audit how it became writable.",
            evidence="\n".join(f"{s}: {p}" for s, p in risky_services),
        ))
    else:
        findings.append(Finding(
            module="Services",
            title="No root services with writable ExecStart targets found",
            detail="Checked all running services for writable executable targets.",
            severity=Severity.INFO,
            exploitability="N/A",
            mitigation="N/A",
        ))

    return findings


def scan_sudo():
    findings = []
    out, err, rc = run_cmd("sudo -n -l 2>&1")

    if rc != 0 or "password is required" in out.lower() or "may not run sudo" in out.lower():
        findings.append(Finding(
            module="Sudo",
            title="sudo -l not accessible without a password / no sudo rights",
            detail="Non-interactive sudo -l did not return rules (no rights, or password required).",
            severity=Severity.INFO,
            exploitability="N/A -- cannot enumerate rules without a password prompt.",
            mitigation="N/A",
            evidence=out or err,
        ))
        return findings

    nopasswd_lines = [l for l in out.splitlines() if "NOPASSWD" in l]
    all_all_lines = [l for l in out.splitlines() if re.search(r"\(ALL(\s*:\s*ALL)?\)\s*ALL", l)]

    if nopasswd_lines:
        findings.append(Finding(
            module="Sudo",
            title="NOPASSWD sudo rule(s) found",
            detail=(
                "The current user can run the following via sudo with no "
                "password prompt:\n" + "\n".join(f"  - {l.strip()}" for l in nopasswd_lines)
            ),
            severity=Severity.HIGH,
            exploitability=(
                "If the allowed command is a GTFOBins entry (e.g. vim, find, "
                "awk, less), it can typically be used to spawn a root shell."
            ),
            mitigation="Restrict sudoers entries to the minimum required commands; remove NOPASSWD where not essential.",
            evidence="\n".join(nopasswd_lines),
        ))

    if all_all_lines:
        findings.append(Finding(
            module="Sudo",
            title="Unrestricted (ALL) sudo rule found",
            detail="The user can run ALL commands via sudo:\n" + "\n".join(all_all_lines),
            severity=Severity.CRITICAL,
            exploitability="Direct path to root via `sudo <anything>` (may require password).",
            mitigation="Scope sudoers entries to specific commands rather than ALL.",
            evidence="\n".join(all_all_lines),
        ))

    if not nopasswd_lines and not all_all_lines:
        findings.append(Finding(
            module="Sudo",
            title="Sudo rules present but no obvious NOPASSWD/ALL escalation",
            detail="sudo -l returned rules; manual review still recommended:\n" + out,
            severity=Severity.LOW,
            exploitability="Review each allowed command against GTFOBins.",
            mitigation="N/A",
            evidence=out,
        ))

    return findings


def scan():
    return scan_services() + scan_sudo()
