"""
Weak File & Directory Permissions
Finds world-writable files, writable files owned/used by root
(cron scripts, service files), and checks core auth file permissions.
"""

import os
from .common import Finding, Severity, run_cmd

CRITICAL_FILES = ["/etc/passwd", "/etc/shadow", "/etc/sudoers", "/etc/group"]


def scan():
    findings = []

    # World-writable files (excluding common noisy pseudo-filesystems)
    ww_out, _, _ = run_cmd(
        "find / -xdev -type f -perm -0002 "
        "-not -path '/proc/*' -not -path '/sys/*' -not -path '/tmp/*' "
        "-not -path '/dev/*' 2>/dev/null"
    )
    ww_files = [l for l in ww_out.splitlines() if l.strip()]
    if ww_files:
        findings.append(Finding(
            module="Permissions",
            title=f"{len(ww_files)} world-writable file(s) found",
            detail=(
                "These files can be modified by any local user, regardless of "
                "ownership. If any are read or executed by a privileged process, "
                "this is a direct escalation path:\n" +
                "\n".join(f"  - {p}" for p in ww_files[:50]) +
                ("\n  ... (truncated)" if len(ww_files) > 50 else "")
            ),
            severity=Severity.MEDIUM,
            exploitability=(
                "Check whether any listed file is read/executed by root (a "
                "service, cron job, or startup script). If so this becomes HIGH."
            ),
            mitigation="Remove world-write: chmod o-w <path>. Set correct ownership.",
            evidence="\n".join(ww_files),
        ))

    # World-writable directories without the sticky bit (classic /tmp-style risk
    # anywhere else on the filesystem)
    wwd_out, _, _ = run_cmd(
        "find / -xdev -type d -perm -0002 ! -perm -1000 "
        "-not -path '/proc/*' -not -path '/sys/*' 2>/dev/null"
    )
    wwd_dirs = [l for l in wwd_out.splitlines() if l.strip()]
    if wwd_dirs:
        findings.append(Finding(
            module="Permissions",
            title=f"{len(wwd_dirs)} world-writable directory(ies) without sticky bit",
            detail=(
                "Any local user can create, rename, or delete files inside these "
                "directories, including files owned by other users:\n" +
                "\n".join(f"  - {p}" for p in wwd_dirs[:30])
            ),
            severity=Severity.LOW,
            exploitability="Useful for planting files a privileged process might load.",
            mitigation="Set the sticky bit: chmod +t <dir>, or tighten write access.",
            evidence="\n".join(wwd_dirs),
        ))

    # Critical auth files: check they aren't group/world writable
    for f in CRITICAL_FILES:
        if not os.path.exists(f):
            continue
        try:
            mode = oct(os.stat(f).st_mode)[-3:]
            group_writable = int(mode[1]) & 2
            world_writable = int(mode[2]) & 2
            if group_writable or world_writable:
                findings.append(Finding(
                    module="Permissions",
                    title=f"{f} has overly permissive mode ({mode})",
                    detail=(
                        f"{f} is writable by group and/or other users (mode {mode}). "
                        "This file controls system authentication/authorization."
                    ),
                    severity=Severity.CRITICAL,
                    exploitability=(
                        f"Writing to {f} directly can grant root (e.g. adding a "
                        "UID-0 user, or in the case of shadow, controlling a hash)."
                    ),
                    mitigation=f"Restore correct permissions, typically: chmod 644 {f} "
                               f"(or 640/600 for shadow) and chown root:root {f}.",
                    evidence=f"mode={mode}",
                ))
        except Exception:
            continue

    if not findings:
        findings.append(Finding(
            module="Permissions",
            title="No weak world-writable files/dirs or critical file issues found",
            detail="Scan completed with no findings in this category.",
            severity=Severity.INFO,
            exploitability="N/A",
            mitigation="N/A",
        ))

    return findings
