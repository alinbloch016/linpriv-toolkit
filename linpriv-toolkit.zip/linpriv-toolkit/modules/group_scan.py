"""
Container & Privileged Group Membership
Membership in certain groups is functionally equivalent to root access
via well-documented escape techniques, even though the user is never
literally SUID-root:
  - docker  : can mount the host filesystem into a privileged container
  - lxd/lxc : same idea via LXD container profiles
  - disk    : raw access to block devices (can read/write any file via /dev/sdX)
  - adm     : broad log-reading rights (lower severity, informational)
"""

from .common import Finding, Severity, run_cmd

CRITICAL_GROUPS = {
    "docker": "Can start a privileged container with the host filesystem "
              "bind-mounted, then chroot into it as root.",
    "lxd": "Can create an LXD container with security.privileged=true and "
           "mount the host filesystem, achieving root on the host.",
    "lxc": "Similar to lxd -- container privilege boundary can be bypassed.",
    "disk": "Raw read/write access to block devices (e.g. /dev/sda) allows "
            "bypassing filesystem permissions entirely.",
}

INFO_GROUPS = {
    "adm": "Broad log-file read access -- not root-equivalent, but useful "
           "for reconnaissance (credentials sometimes leak into logs).",
}


def scan():
    findings = []

    out, _, rc = run_cmd("id -nG")
    if rc != 0:
        findings.append(Finding(
            module="Group Membership",
            title="Could not determine group membership",
            detail="`id -nG` failed.",
            severity=Severity.INFO,
            exploitability="N/A",
            mitigation="N/A",
        ))
        return findings

    groups = set(out.split())

    critical_hits = {g: CRITICAL_GROUPS[g] for g in groups if g in CRITICAL_GROUPS}
    info_hits = {g: INFO_GROUPS[g] for g in groups if g in INFO_GROUPS}

    for g, explanation in critical_hits.items():
        findings.append(Finding(
            module="Group Membership",
            title=f"User is a member of the '{g}' group",
            detail=(
                f"Membership in '{g}' is functionally equivalent to root "
                f"access via a well-documented technique: {explanation}"
            ),
            severity=Severity.CRITICAL,
            exploitability=explanation,
            mitigation=f"Remove the user from '{g}' unless container/disk "
                       f"access is an explicit, intended privilege.",
            evidence=f"groups: {out}",
        ))

    for g, explanation in info_hits.items():
        findings.append(Finding(
            module="Group Membership",
            title=f"User is a member of the '{g}' group",
            detail=explanation,
            severity=Severity.LOW,
            exploitability=explanation,
            mitigation="Review whether this access level is still required.",
            evidence=f"groups: {out}",
        ))

    if not critical_hits and not info_hits:
        findings.append(Finding(
            module="Group Membership",
            title="No privilege-equivalent group memberships found",
            detail=f"Current groups: {out}",
            severity=Severity.INFO,
            exploitability="N/A",
            mitigation="N/A",
        ))

    return findings
