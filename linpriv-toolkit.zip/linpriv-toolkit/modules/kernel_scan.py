"""
Kernel Exploit Detection (detection only -- no live exploits run)
Captures kernel version and flags it if it looks old enough to
plausibly be missing security patches. Does NOT attempt to fingerprint
or run any specific CVE exploit; it simply surfaces the version so the
analyst can cross-reference it against a CVE database themselves.
"""

import re
from .common import Finding, Severity, run_cmd

# Kernel major.minor versions considered end-of-life / unsupported as a
# rough heuristic for this student project. Update as needed -- this is
# NOT an authoritative CVE feed.
OLD_KERNEL_THRESHOLD = (5, 4)  # anything older than 5.4 flagged as likely stale


def scan():
    findings = []

    out, _, _ = run_cmd("uname -r")
    version_str = out.strip()

    findings.append(Finding(
        module="Kernel",
        title=f"Kernel version: {version_str}",
        detail=(
            f"Running kernel reported as {version_str}. Cross-reference this "
            "against a current CVE database (e.g. cve.org, distro security "
            "trackers) for known local-privilege-escalation vulnerabilities."
        ),
        severity=Severity.INFO,
        exploitability="See mitigation -- manual CVE lookup required.",
        mitigation=(
            "Look up this exact version string against your distro's kernel "
            "CVE tracker before drawing conclusions."
        ),
        evidence=version_str,
    ))

    match = re.match(r"(\d+)\.(\d+)", version_str)
    if match:
        major, minor = int(match.group(1)), int(match.group(2))
        if (major, minor) < OLD_KERNEL_THRESHOLD:
            findings.append(Finding(
                module="Kernel",
                title="Kernel version appears outdated",
                detail=(
                    f"Kernel {version_str} is older than the {OLD_KERNEL_THRESHOLD[0]}."
                    f"{OLD_KERNEL_THRESHOLD[1]} baseline used by this toolkit as a "
                    "rough staleness heuristic. Older kernels are statistically "
                    "more likely to have unpatched local privilege escalation bugs."
                ),
                severity=Severity.MEDIUM,
                exploitability=(
                    "Not exploited by this toolkit. Manually check the version "
                    "against a CVE database for confirmed local privesc bugs "
                    "before treating this as actionable."
                ),
                mitigation="Update to a current, vendor-supported kernel version.",
                evidence=version_str,
            ))

    # Distro / EOL context, if available
    os_release, _, rc = run_cmd("cat /etc/os-release 2>/dev/null")
    if rc == 0 and os_release:
        findings.append(Finding(
            module="Kernel",
            title="OS release info",
            detail="Captured for cross-referencing distro EOL status.",
            severity=Severity.INFO,
            exploitability="N/A",
            mitigation="Confirm this distro release is still within its support window.",
            evidence=os_release,
        ))

    return findings
