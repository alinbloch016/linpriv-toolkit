"""
Linux Capabilities Scan
Modern privilege escalation increasingly happens via file capabilities
(setcap) rather than the SUID bit -- e.g. cap_setuid+ep on a binary lets
it set its own UID to 0 without ever being SUID root. This is a common
blind spot in checklists that only look for SUID/SGID.
"""

from .common import Finding, Severity, run_cmd

# Capabilities that are effectively equivalent to a root-granting SUID bit
# if present on an attacker-runnable binary.
DANGEROUS_CAPS = {
    "cap_setuid", "cap_setgid", "cap_sys_admin", "cap_sys_ptrace",
    "cap_dac_override", "cap_dac_read_search", "cap_sys_module",
    "cap_sys_rawio", "cap_net_raw", "cap_chown",
}


def scan():
    findings = []

    out, err, rc = run_cmd("getcap -r / 2>/dev/null")
    if rc != 0 and not out:
        findings.append(Finding(
            module="Capabilities",
            title="getcap not available or scan failed",
            detail=f"Could not enumerate file capabilities. ({err or 'no getcap binary found'})",
            severity=Severity.INFO,
            exploitability="N/A",
            mitigation="Install libcap2-bin (getcap/setcap) to enable this check.",
        ))
        return findings

    lines = [l for l in out.splitlines() if l.strip()]
    risky = []
    for line in lines:
        lower = line.lower()
        if any(cap in lower for cap in DANGEROUS_CAPS):
            risky.append(line)

    if risky:
        findings.append(Finding(
            module="Capabilities",
            title=f"{len(risky)} binary(ies) with dangerous capabilities",
            detail=(
                "These binaries carry Linux capabilities that can be abused "
                "for privilege escalation even without the SUID bit set "
                "(e.g. cap_setuid lets a process set its own UID to 0):\n" +
                "\n".join(f"  - {l}" for l in risky)
            ),
            severity=Severity.HIGH,
            exploitability=(
                "Check GTFOBins' 'Capabilities' section for the specific "
                "binary -- many interpreters (python, perl) with cap_setuid "
                "grant an immediate root shell."
            ),
            mitigation="Remove the capability if unneeded: setcap -r <path>.",
            evidence="\n".join(risky),
        ))

    if lines:
        findings.append(Finding(
            module="Capabilities",
            title=f"Full capability inventory ({len(lines)} entries)",
            detail="All files with any capability set, for manual review.",
            severity=Severity.INFO,
            exploitability="N/A -- informational.",
            mitigation="Review against baseline.",
            evidence="\n".join(lines),
        ))
    else:
        findings.append(Finding(
            module="Capabilities",
            title="No files with capabilities found",
            detail="getcap -r / returned no results.",
            severity=Severity.INFO,
            exploitability="N/A",
            mitigation="N/A",
        ))

    return findings
