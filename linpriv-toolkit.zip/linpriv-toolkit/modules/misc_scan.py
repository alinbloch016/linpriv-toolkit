"""
Misc High-Value Checks:
  - NFS exports with no_root_squash (lets a remote root map to local root)
  - Extra UID 0 accounts in /etc/passwd (a classic persistence/backdoor sign)
  - Writable /etc/ld.so.preload (arbitrary code injection into every
    dynamically-linked process that starts afterward)
"""

import os
from .common import Finding, Severity, run_cmd


def _is_writable_by_others(path):
    try:
        st = os.stat(path)
        mode = oct(st.st_mode)[-3:]
        return (int(mode[1]) & 2) or (int(mode[2]) & 2)
    except Exception:
        return False


def scan_nfs():
    findings = []
    if not os.path.isfile("/etc/exports"):
        return findings

    content, _, _ = run_cmd("cat /etc/exports 2>/dev/null")
    risky_lines = [
        l for l in content.splitlines()
        if l.strip() and not l.strip().startswith("#") and "no_root_squash" in l
    ]

    if risky_lines:
        findings.append(Finding(
            module="NFS",
            title=f"{len(risky_lines)} NFS export(s) with no_root_squash",
            detail=(
                "These exports allow a remote root user to act as root on "
                "the exported filesystem:\n" + "\n".join(f"  - {l}" for l in risky_lines)
            ),
            severity=Severity.HIGH,
            exploitability=(
                "If this host can mount the export, or another host with "
                "root access can, files can be planted with root ownership "
                "and SUID bits, then executed locally for privilege escalation."
            ),
            mitigation="Remove no_root_squash from /etc/exports unless explicitly required; re-export.",
            evidence="\n".join(risky_lines),
        ))
    return findings


def scan_backdoor_accounts():
    findings = []
    content, _, rc = run_cmd("cat /etc/passwd 2>/dev/null")
    if rc != 0:
        return findings

    uid0_users = []
    for line in content.splitlines():
        parts = line.split(":")
        if len(parts) >= 3 and parts[2] == "0" and parts[0] != "root":
            uid0_users.append(line)

    if uid0_users:
        findings.append(Finding(
            module="Accounts",
            title=f"{len(uid0_users)} non-'root' account(s) with UID 0",
            detail=(
                "These accounts have UID 0 (full root privileges) despite "
                "not being the standard 'root' account -- a common backdoor "
                "persistence technique:\n" + "\n".join(f"  - {l}" for l in uid0_users)
            ),
            severity=Severity.CRITICAL,
            exploitability="Any of these accounts can be logged into (or already have keys/passwords set) for direct root access.",
            mitigation="Investigate immediately; remove or fix UID on any account that shouldn't have UID 0.",
            evidence="\n".join(uid0_users),
        ))
    return findings


def scan_ld_preload():
    findings = []
    path = "/etc/ld.so.preload"
    if os.path.isfile(path):
        content, _, _ = run_cmd(f"cat {path} 2>/dev/null")
        writable = _is_writable_by_others(path)
        if content.strip() or writable:
            findings.append(Finding(
                module="LD_PRELOAD",
                title="/etc/ld.so.preload exists" + (" and is writable" if writable else ""),
                detail=(
                    f"/etc/ld.so.preload {'is writable by non-root and ' if writable else ''}"
                    f"currently contains: {content or '(empty)'}. Any library listed here "
                    "is loaded into EVERY dynamically-linked process on the system."
                ),
                severity=Severity.CRITICAL if writable else Severity.LOW,
                exploitability=(
                    "Writing a malicious .so path here achieves code execution "
                    "in the context of every process that starts afterward, "
                    "including root-owned ones."
                ),
                mitigation="Restrict write access to root:root 644; remove unexpected entries.",
                evidence=content,
            ))
    return findings


def scan():
    return scan_nfs() + scan_backdoor_accounts() + scan_ld_preload()
