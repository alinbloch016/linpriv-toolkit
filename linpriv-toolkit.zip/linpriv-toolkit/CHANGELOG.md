# Changelog

All notable changes to this project are documented here.

## [2.0.0]

### Added
- Risk scoring engine (`modules/scoring.py`): aggregate 0-100 posture
  score with A-F letter grade, shown in the terminal and all three
  report formats.
- YAML config file support (`modules/config.py`) — `./linpriv.yml`,
  `~/.config/linpriv/config.yml`, or `--config <path>`. CLI flags
  always take precedence over config file values.
- Structured logging (`-v`/`-vv`, `--log-file`) via the standard
  `logging` module, in addition to the rich terminal UI.
- `--fail-on {critical,high,medium,low,none}` — CI-friendly non-zero
  exit code when a finding at or above the given severity is present.
- `--exclude` / `exclude_paths` config option to skip noisy or
  irrelevant mounts in filesystem-wide scans (SUID/SGID, permissions).
- `--version` flag.
- Four new detection modules: Linux capabilities, PATH hijacking,
  privileged group membership (docker/lxd/disk), and a misc module
  covering NFS `no_root_squash`, backdoor UID-0 accounts, and writable
  `/etc/ld.so.preload`.
- JSON report output alongside text and HTML.
- `pyproject.toml` for `pip install`-able packaging with a
  `linpriv-audit` console entry point.
- Dockerfile for containerized runs.
- Graceful, actionable error (instead of a Python traceback) when run
  on a non-Linux platform.
- pytest test suite covering core data structures, the scoring engine,
  and module smoke tests.

### Fixed
- HTML report: `uid=0` rendered as blank due to a falsy-value bug in
  the escaping helper.
- Report generation now correctly threads the risk score through all
  three output formats.

## [1.0.0]

Initial release: rich-powered terminal UI, six core detection modules
(SUID/SGID, permissions, services/sudo, cron, kernel), text/HTML
reports.
