#!/usr/bin/env python3
"""
Linux Privilege Escalation Automation Toolkit
Detection-only auditing tool with a polished terminal UI, aggregate risk
scoring, config file support, and CI-friendly exit codes. Never executes
exploit code -- every check is read-only enumeration.

Run `linpriv-audit --help` (or `python3 main.py --help`) for full usage.
"""

import argparse
import os
import sys
import time
import inspect

if sys.platform not in ("linux", "linux2"):
    sys.stderr.write(
        "\nlinpriv-audit only runs on Linux.\n\n"
        f"Detected platform: {sys.platform}\n\n"
        "This tool audits Linux-specific interfaces (systemd, sudoers,\n"
        "/etc/shadow, SUID/SGID bits, cron, file capabilities) that don't\n"
        "exist on this OS, so it can't run here. Use one of:\n\n"
        "  WSL     : wsl --install   (then run this inside the Ubuntu shell)\n"
        "  Docker  : docker build -t linpriv-audit . && docker run --rm "
        "-v \"$PWD/report_output:/app/report_output\" linpriv-audit\n"
        "  Linux VM: any VirtualBox/VMware/cloud Linux instance\n\n"
    )
    sys.exit(1)

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TimeElapsedColumn
from rich.text import Text
from rich.rule import Rule
from rich.align import Align

from modules import (
    sysinfo, suid_scan, permissions_scan, services_scan, cron_scan,
    kernel_scan, capabilities_scan, path_scan, group_scan, misc_scan, report,
)
from modules.common import Severity, setup_logging, logger
from modules.config import load_config
from modules.scoring import compute_score, worst_severity
from modules._version import __version__

SEVERITY_STYLE = {
    Severity.CRITICAL: "bold white on dark_red",
    Severity.HIGH: "bold red",
    Severity.MEDIUM: "bold yellow",
    Severity.LOW: "bold green",
    Severity.INFO: "dim cyan",
}
SEVERITY_ORDER = [Severity.CRITICAL, Severity.HIGH, Severity.MEDIUM, Severity.LOW, Severity.INFO]

SEVERITY_RANK = {Severity.CRITICAL: 4, Severity.HIGH: 3, Severity.MEDIUM: 2, Severity.LOW: 1, Severity.INFO: 0}
FAIL_ON_CHOICES = ["critical", "high", "medium", "low", "none"]

MODULE_MAP = {
    "suid":         ("SUID/SGID Binaries",       suid_scan.scan),
    "permissions":  ("File & Directory Perms",   permissions_scan.scan),
    "services":     ("Services & Sudo Rules",    services_scan.scan),
    "cron":         ("Cron Jobs",                cron_scan.scan),
    "kernel":       ("Kernel & OS Version",      kernel_scan.scan),
    "capabilities": ("Linux Capabilities",       capabilities_scan.scan),
    "path":         ("PATH Hijacking",           path_scan.scan),
    "groups":       ("Privileged Group Membership", group_scan.scan),
    "misc":         ("NFS / Backdoor Accounts / LD_PRELOAD", misc_scan.scan),
}

GRADE_COLOR = {"A": "bold green", "B": "bold green", "C": "bold yellow", "D": "bold red", "F": "bold white on dark_red"}

BANNER = r"""
[bold red] _     _       ____       _     [/]
[bold red]| |   (_)_ __ |  _ \ _ __(_)_   __[/]
[bold red]| |   | | '_ \| |_) | '__| \ \ / /[/]
[bold red]| |___| | | | |  __/| |  | |\ V / [/]
[bold red]|_____|_|_| |_|_|   |_|  |_| \_/  [/]
[dim]Linux Privilege Escalation Audit Toolkit  v{version}[/]
[dim]detection-only • no exploits executed[/]
"""


def print_banner(console):
    console.print(Align.center(Text.from_markup(BANNER.format(version=__version__))))


def print_sysinfo(console, info):
    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_row("[bold]User[/]", f"{info['username']} (uid={info['uid']})")
    table.add_row("[bold]Root?[/]", "[bold red]YES[/]" if info["is_root"] else "no")
    table.add_row("[bold]Host[/]", info["hostname"])
    table.add_row("[bold]Kernel[/]", info["kernel"])
    console.print(Panel(table, title="System Information", border_style="blue", expand=False))
    if info["is_root"]:
        console.print("[dim]Already running as root -- checks still run to surface vectors other users could abuse.[/]\n")


def run_scans(console, selected, exclude_paths):
    all_findings = []

    with Progress(
        SpinnerColumn(style="cyan"),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TimeElapsedColumn(),
        console=console,
        transient=False,
    ) as progress:
        overall = progress.add_task("[bold]Overall scan progress[/]", total=len(selected))

        for key in selected:
            label, fn = MODULE_MAP[key]
            task = progress.add_task(f"Scanning: {label}", total=None)
            start = time.time()
            try:
                if "exclude_paths" in inspect.signature(fn).parameters:
                    findings = fn(exclude_paths=exclude_paths)
                else:
                    findings = fn()
                all_findings.extend(findings)
                logger.info("Module '%s' produced %d findings", key, len(findings))
            except Exception as e:
                logger.warning("Module '%s' failed: %s", key, e)
                console.print(f"  [bold red]![/] Module '{key}' failed: {e}")
            elapsed = time.time() - start
            progress.update(task, completed=1, total=1, description=f"[green]done[/] {label} ({elapsed:.1f}s)")
            progress.advance(overall)

    return all_findings


def print_risk_score(console, score_data):
    grade = score_data["grade"]
    color = GRADE_COLOR.get(grade, "bold white")
    border = "red" if "dark_red" in color else color.split()[-1]
    body = Text()
    body.append(f"{score_data['score']}/100", style=color)
    body.append("   grade: ", style="dim")
    body.append(grade, style=color)
    body.append(f"\n{score_data['grade_label']}", style="dim")
    console.print(Panel(body, title="Security Posture Score", border_style=border, expand=False))


def print_summary_table(console, findings):
    counts = {}
    for f in findings:
        counts[f.severity] = counts.get(f.severity, 0) + 1

    table = Table(title="Scan Summary", show_lines=False, header_style="bold")
    table.add_column("Severity")
    table.add_column("Count", justify="right")
    for sev in SEVERITY_ORDER:
        n = counts.get(sev, 0)
        style = SEVERITY_STYLE[sev]
        table.add_row(f"[{style}]{sev}[/]", str(n))
    console.print(table)


def print_findings(console, findings, show_info=False):
    findings_sorted = sorted(findings, key=lambda f: SEVERITY_ORDER.index(f.severity))
    console.print(Rule("[bold]Findings[/]", style="dim"))

    shown = 0
    for f in findings_sorted:
        if f.severity == Severity.INFO and not show_info:
            continue
        style = SEVERITY_STYLE[f.severity]
        header = Text()
        header.append(f" {f.severity} ", style=style)
        header.append(f"  [{f.module}]  ", style="bold")
        header.append(f.title, style="bold")

        body = Text()
        first_line = f.detail.splitlines()[0] if f.detail else ""
        body.append("Detail: ", style="bold dim")
        body.append(first_line + "\n")
        body.append("Exploitability: ", style="bold dim")
        body.append(f.exploitability + "\n")
        body.append("Mitigation: ", style="bold dim")
        body.append(f.mitigation)

        border = {
            Severity.CRITICAL: "dark_red", Severity.HIGH: "red",
            Severity.MEDIUM: "yellow", Severity.LOW: "green", Severity.INFO: "cyan",
        }[f.severity]

        console.print(Panel(body, title=header, border_style=border, title_align="left"))
        shown += 1

    if shown == 0:
        console.print("[dim]No actionable (non-INFO) findings. Run with --show-info for the full inventory.[/]")


def build_parser():
    parser = argparse.ArgumentParser(
        prog="linpriv-audit",
        description="Linux Privilege Escalation Audit Toolkit (detection only, no exploits executed)"
    )
    parser.add_argument("--version", action="version", version=f"linpriv-audit {__version__}")
    parser.add_argument("--config", help="Path to a YAML config file (default: ./linpriv.yml or ~/.config/linpriv/config.yml)")
    parser.add_argument("--out-dir", help="Directory to write reports to (default: ./report_output)")
    parser.add_argument(
        "--modules",
        help="Comma-separated modules to run: " + ",".join(MODULE_MAP.keys()) + " (default: all)"
    )
    parser.add_argument("--exclude", help="Comma-separated paths to exclude from filesystem scans")
    parser.add_argument("--show-info", action="store_true", help="Include INFO-level findings in terminal output")
    parser.add_argument("--no-color", action="store_true", help="Disable colored/rich output (plain text)")
    parser.add_argument("--list-modules", action="store_true", help="List available modules and exit")
    parser.add_argument(
        "--fail-on", choices=FAIL_ON_CHOICES,
        help="Exit non-zero if a finding at or above this severity is found (default: high). Use 'none' to always exit 0."
    )
    parser.add_argument("-v", "--verbose", action="count", default=0, help="Increase log verbosity (-v info, -vv debug)")
    parser.add_argument("--log-file", help="Write logs to this file in addition to stderr")
    return parser


def main():
    parser = build_parser()
    args = parser.parse_args()

    config, config_source, config_warning = load_config(args.config)

    out_dir = args.out_dir or config["out_dir"]
    modules_arg = args.modules or config["modules"]
    fail_on = args.fail_on or config["fail_on"]
    show_info = args.show_info or config["show_info"]
    exclude_paths = args.exclude.split(",") if args.exclude else config["exclude_paths"]

    setup_logging(verbosity=args.verbose, log_file=args.log_file)

    console = Console(no_color=args.no_color, highlight=False)

    if args.list_modules:
        for key, (label, _) in MODULE_MAP.items():
            console.print(f"  [bold cyan]{key:<14}[/] {label}")
        return 0

    if config_warning:
        console.print(f"[yellow]![/] {config_warning}")
    if config_source:
        logger.info("Loaded config from %s", config_source)

    os.makedirs(out_dir, exist_ok=True)

    print_banner(console)

    info = sysinfo.gather()
    print_sysinfo(console, info)

    selected = list(MODULE_MAP.keys()) if modules_arg == "all" else [m.strip() for m in modules_arg.split(",")]
    unknown = [m for m in selected if m not in MODULE_MAP]
    for u in unknown:
        console.print(f"[yellow]![/] Unknown module '{u}', skipping.")
    selected = [m for m in selected if m in MODULE_MAP]

    console.print()
    all_findings = run_scans(console, selected, exclude_paths)
    console.print()

    score_data = compute_score(all_findings)
    print_risk_score(console, score_data)
    console.print()

    print_summary_table(console, all_findings)
    console.print()
    print_findings(console, all_findings, show_info=show_info)

    text_path = os.path.join(out_dir, "privesc_report.txt")
    html_path = os.path.join(out_dir, "privesc_report.html")
    json_path = os.path.join(out_dir, "privesc_report.json")
    report.write_text_report(all_findings, info, text_path, score_data)
    report.write_html_report(all_findings, info, html_path, score_data)
    report.write_json_report(all_findings, info, json_path, score_data)

    console.print()
    console.print(Panel(
        f"[bold]{text_path}[/]\n[bold]{html_path}[/]\n[bold]{json_path}[/]",
        title="Reports written", border_style="green", expand=False,
    ))

    if fail_on == "none":
        return 0
    worst = worst_severity(all_findings)
    if worst and SEVERITY_RANK.get(worst, 0) >= SEVERITY_RANK.get(fail_on, 3):
        console.print(f"\n[bold red]Exiting non-zero: worst finding severity '{worst}' meets --fail-on threshold '{fail_on}'[/]")
        return 2
    return 0


if __name__ == "__main__":
    if sys.platform not in ("linux", "linux2"):
        print("Warning: this toolkit is designed for Linux systems. Some checks may not work here "
              "(try WSL, a Linux VM, or the provided Docker image).")
    sys.exit(main())
