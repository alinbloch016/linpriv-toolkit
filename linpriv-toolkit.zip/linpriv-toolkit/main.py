#!/usr/bin/env python3
"""
Linux Privilege Escalation Automation Toolkit
Detection-only auditing tool with a polished terminal UI (via `rich`).
Scans for common privesc vectors and produces a severity-ranked report
in text, HTML, and JSON. Never executes exploit code.

Usage:
    python3 main.py [--out-dir DIR] [--modules MOD1,MOD2,...] [--no-color] [--quiet]

Run `python3 main.py --list-modules` to see all available modules.
"""

import argparse
import os
import sys
import time

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TimeElapsedColumn
from rich.text import Text
from rich.rule import Rule
from rich.align import Align

from modules import (
    sysinfo, suid_scan, permissions_scan, services_scan, cron_scan,
    kernel_scan, capabilities_scan, path_scan, group_scan, misc_scan, report,
)
from modules.common import Severity

SEVERITY_STYLE = {
    Severity.CRITICAL: "bold white on dark_red",
    Severity.HIGH: "bold red",
    Severity.MEDIUM: "bold yellow",
    Severity.LOW: "bold green",
    Severity.INFO: "dim cyan",
}
SEVERITY_ORDER = [Severity.CRITICAL, Severity.HIGH, Severity.MEDIUM, Severity.LOW, Severity.INFO]

MODULE_MAP = {
    "suid":         ("SUID/SGID Binaries",       suid_scan.scan),
    "permissions":  ("File & Directory Perms",   permissions_scan.scan),
    "services":     ("Services & Sudo Rules",    services_scan.scan),
    "cron":         ("Cron Jobs",                cron_scan.scan),
    "kernel":       ("Kernel & OS Version",      kernel_scan.scan),
    "capabilities": ("Linux Capabilities",       capabilities_scan.scan),
    "path":         ("PATH Hijacking",           path_scan.scan),
    "groups":       ("Privileged Group Membership", group_scan.scan),
    "misc":         ("NFS / Backdoor Accounts / LD_PRELOAD", misc_scan.scan),
}

BANNER = r"""
[bold red] _     _       ____       _     [/]
[bold red]| |   (_)_ __ |  _ \ _ __(_)_   __[/]
[bold red]| |   | | '_ \| |_) | '__| \ \ / /[/]
[bold red]| |___| | | | |  __/| |  | |\ V / [/]
[bold red]|_____|_|_| |_|_|   |_|  |_| \_/  [/]
[dim]Linux Privilege Escalation Audit Toolkit[/]
[dim]detection-only • no exploits executed[/]
"""


def print_banner(console):
    console.print(Align.center(Text.from_markup(BANNER)))


def print_sysinfo(console, info):
    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_row("[bold]User[/]", f"{info['username']} (uid={info['uid']})")
    table.add_row("[bold]Root?[/]", "[bold red]YES[/]" if info["is_root"] else "no")
    table.add_row("[bold]Host[/]", info["hostname"])
    table.add_row("[bold]Kernel[/]", info["kernel"])
    console.print(Panel(table, title="System Information", border_style="blue", expand=False))
    if info["is_root"]:
        console.print("[dim]Already running as root -- checks still run to surface vectors other users could abuse.[/]\n")


def run_scans(console, selected):
    all_findings = []
    module_counts = {}

    with Progress(
        SpinnerColumn(style="cyan"),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TimeElapsedColumn(),
        console=console,
        transient=False,
    ) as progress:
        overall = progress.add_task("[bold]Overall scan progress[/]", total=len(selected))

        for key in selected:
            label, fn = MODULE_MAP[key]
            task = progress.add_task(f"Scanning: {label}", total=None)
            start = time.time()
            try:
                findings = fn()
                all_findings.extend(findings)
                module_counts[label] = len(findings)
            except Exception as e:
                console.print(f"  [bold red]![/] Module '{key}' failed: {e}")
                module_counts[label] = 0
            elapsed = time.time() - start
            progress.update(task, completed=1, total=1, description=f"[green]done[/] {label} ({elapsed:.1f}s)")
            progress.advance(overall)

    return all_findings


def print_summary_table(console, findings):
    counts = {}
    for f in findings:
        counts[f.severity] = counts.get(f.severity, 0) + 1

    table = Table(title="Scan Summary", show_lines=False, header_style="bold")
    table.add_column("Severity")
    table.add_column("Count", justify="right")
    for sev in SEVERITY_ORDER:
        n = counts.get(sev, 0)
        style = SEVERITY_STYLE[sev]
        table.add_row(f"[{style}]{sev}[/]", str(n))
    console.print(table)


def print_findings(console, findings, show_info=False):
    findings_sorted = sorted(findings, key=lambda f: SEVERITY_ORDER.index(f.severity))
    console.print(Rule("[bold]Findings[/]", style="dim"))

    shown = 0
    for f in findings_sorted:
        if f.severity == Severity.INFO and not show_info:
            continue
        style = SEVERITY_STYLE[f.severity]
        header = Text()
        header.append(f" {f.severity} ", style=style)
        header.append(f"  [{f.module}]  ", style="bold")
        header.append(f.title, style="bold")

        body = Text()
        first_line = f.detail.splitlines()[0] if f.detail else ""
        body.append("Detail: ", style="bold dim")
        body.append(first_line + "\n")
        body.append("Exploitability: ", style="bold dim")
        body.append(f.exploitability + "\n")
        body.append("Mitigation: ", style="bold dim")
        body.append(f.mitigation)

        border = {
            Severity.CRITICAL: "dark_red", Severity.HIGH: "red",
            Severity.MEDIUM: "yellow", Severity.LOW: "green", Severity.INFO: "cyan",
        }[f.severity]

        console.print(Panel(body, title=header, border_style=border, title_align="left"))
        shown += 1

    if shown == 0:
        console.print("[dim]No actionable (non-INFO) findings. Run with --show-info for the full inventory.[/]")


def main():
    parser = argparse.ArgumentParser(description="Linux Privilege Escalation Audit Toolkit (detection only)")
    parser.add_argument("--out-dir", default="./report_output", help="Directory to write reports to")
    parser.add_argument(
        "--modules", default="all",
        help="Comma-separated modules to run: " + ",".join(MODULE_MAP.keys()) + " (default: all)"
    )
    parser.add_argument("--show-info", action="store_true", help="Include INFO-level findings in terminal output")
    parser.add_argument("--no-color", action="store_true", help="Disable colored/rich output (plain text)")
    parser.add_argument("--list-modules", action="store_true", help="List available modules and exit")
    args = parser.parse_args()

    console = Console(no_color=args.no_color, highlight=False)

    if args.list_modules:
        for key, (label, _) in MODULE_MAP.items():
            console.print(f"  [bold cyan]{key:<14}[/] {label}")
        return

    os.makedirs(args.out_dir, exist_ok=True)

    print_banner(console)

    info = sysinfo.gather()
    print_sysinfo(console, info)

    selected = list(MODULE_MAP.keys()) if args.modules == "all" else [m.strip() for m in args.modules.split(",")]
    unknown = [m for m in selected if m not in MODULE_MAP]
    for u in unknown:
        console.print(f"[yellow]![/] Unknown module '{u}', skipping.")
    selected = [m for m in selected if m in MODULE_MAP]

    console.print()
    all_findings = run_scans(console, selected)
    console.print()

    print_summary_table(console, all_findings)
    console.print()
    print_findings(console, all_findings, show_info=args.show_info)

    text_path = os.path.join(args.out_dir, "privesc_report.txt")
    html_path = os.path.join(args.out_dir, "privesc_report.html")
    json_path = os.path.join(args.out_dir, "privesc_report.json")
    report.write_text_report(all_findings, info, text_path)
    report.write_html_report(all_findings, info, html_path)
    report.write_json_report(all_findings, info, json_path)

    console.print()
    console.print(Panel(
        f"[bold]{text_path}[/]\n[bold]{html_path}[/]\n[bold]{json_path}[/]",
        title="Reports written", border_style="green", expand=False,
    ))


if __name__ == "__main__":
    if sys.platform not in ("linux", "linux2"):
        print("Warning: this toolkit is designed for Linux systems. Some checks may not work here.")
    main()
