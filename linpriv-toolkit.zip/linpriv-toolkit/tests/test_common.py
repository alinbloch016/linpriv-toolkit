"""Tests for modules.common: Finding, Severity ordering, run_cmd, exclude clauses."""

import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from modules.common import Finding, Severity, run_cmd, build_find_excludes


def test_severity_order_ranks_critical_first():
    assert Severity.ORDER[Severity.CRITICAL] < Severity.ORDER[Severity.HIGH]
    assert Severity.ORDER[Severity.HIGH] < Severity.ORDER[Severity.MEDIUM]
    assert Severity.ORDER[Severity.MEDIUM] < Severity.ORDER[Severity.LOW]
    assert Severity.ORDER[Severity.LOW] < Severity.ORDER[Severity.INFO]


def test_finding_to_dict_roundtrip():
    f = Finding(
        module="Test",
        title="Example finding",
        detail="Some detail",
        severity=Severity.HIGH,
        exploitability="Explanation",
        mitigation="Fix it",
        evidence="raw output",
    )
    d = f.to_dict()
    assert d["module"] == "Test"
    assert d["severity"] == "HIGH"
    assert d["evidence"] == "raw output"


def test_finding_evidence_defaults_to_none():
    f = Finding(
        module="Test", title="t", detail="d",
        severity=Severity.INFO, exploitability="e", mitigation="m",
    )
    assert f.evidence is None


def test_run_cmd_basic_success():
    out, err, rc = run_cmd("echo hello")
    assert rc == 0
    assert out == "hello"


def test_run_cmd_nonexistent_command_does_not_raise():
    out, err, rc = run_cmd("this_command_should_not_exist_xyz")
    assert rc != 0


def test_run_cmd_timeout_does_not_raise():
    out, err, rc = run_cmd("sleep 5", timeout=1)
    assert rc == -1
    assert "timed out" in err.lower()


def test_build_find_excludes_empty():
    assert build_find_excludes([]) == ""
    assert build_find_excludes(None) == ""


def test_build_find_excludes_formats_paths():
    clause = build_find_excludes(["/proc", "/sys"])
    assert "-not -path '/proc/*'" in clause
    assert "-not -path '/proc'" in clause
    assert "-not -path '/sys/*'" in clause
