"""
Smoke tests: every module's scan() should run without raising and
return a list of Finding objects, on this (Linux) test environment.
Not asserting on specific findings (those are host-dependent) --
just that the toolkit's core contract holds.
"""

import sys
import os
import pytest

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from modules.common import Finding
from modules import (
    suid_scan, permissions_scan, services_scan, cron_scan,
    kernel_scan, capabilities_scan, path_scan, group_scan, misc_scan,
)

pytestmark = pytest.mark.skipif(sys.platform not in ("linux", "linux2"), reason="Linux-only toolkit")

MODULES_NO_ARGS = [
    services_scan, cron_scan, kernel_scan, capabilities_scan,
    path_scan, group_scan, misc_scan,
]
MODULES_WITH_EXCLUDE = [suid_scan, permissions_scan]


@pytest.mark.parametrize("module", MODULES_NO_ARGS)
def test_module_scan_returns_findings_list(module):
    findings = module.scan()
    assert isinstance(findings, list)
    for f in findings:
        assert isinstance(f, Finding)
        assert f.severity in ("CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO")


@pytest.mark.parametrize("module", MODULES_WITH_EXCLUDE)
def test_filesystem_module_respects_exclude_paths(module):
    findings = module.scan(exclude_paths=["/proc", "/sys", "/dev", "/tmp"])
    assert isinstance(findings, list)
    for f in findings:
        assert isinstance(f, Finding)


def test_sysinfo_gather_has_required_keys():
    from modules import sysinfo
    info = sysinfo.gather()
    for key in ("username", "uid", "is_root", "kernel", "hostname"):
        assert key in info
