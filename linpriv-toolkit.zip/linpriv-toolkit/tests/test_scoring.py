"""Tests for modules.scoring: risk score computation and grading."""

import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from modules.common import Finding, Severity
from modules.scoring import compute_score, worst_severity


def _finding(severity):
    return Finding(
        module="Test", title="t", detail="d",
        severity=severity, exploitability="e", mitigation="m",
    )


def test_empty_findings_score_100_grade_a():
    result = compute_score([])
    assert result["score"] == 100
    assert result["grade"] == "A"


def test_info_only_findings_do_not_reduce_score():
    findings = [_finding(Severity.INFO) for _ in range(20)]
    result = compute_score(findings)
    assert result["score"] == 100


def test_single_critical_reduces_score_significantly():
    result = compute_score([_finding(Severity.CRITICAL)])
    assert result["score"] < 100
    assert result["score"] <= 75  # single CRITICAL should hurt a lot


def test_score_never_goes_below_zero():
    findings = [_finding(Severity.CRITICAL) for _ in range(50)]
    result = compute_score(findings)
    assert result["score"] >= 0


def test_diminishing_returns_on_repeated_same_severity():
    one = compute_score([_finding(Severity.LOW)])
    five = compute_score([_finding(Severity.LOW) for _ in range(5)])
    # 5 LOW findings should cost more than 1, but less than 5x as much
    deduction_one = 100 - one["score"]
    deduction_five = 100 - five["score"]
    assert deduction_five > deduction_one
    assert deduction_five < deduction_one * 5


def test_worst_severity_picks_highest_present():
    findings = [_finding(Severity.INFO), _finding(Severity.MEDIUM), _finding(Severity.LOW)]
    assert worst_severity(findings) == Severity.MEDIUM


def test_worst_severity_none_when_no_findings():
    assert worst_severity([]) is None


def test_grade_thresholds_are_monotonic():
    # A higher score should never produce a "worse" letter grade
    scores_and_grades = []
    for n_critical in range(0, 6):
        findings = [_finding(Severity.CRITICAL) for _ in range(n_critical)]
        result = compute_score(findings)
        scores_and_grades.append((result["score"], result["grade"]))
    grade_rank = {"A": 0, "B": 1, "C": 2, "D": 3, "F": 4}
    for i in range(1, len(scores_and_grades)):
        prev_score, prev_grade = scores_and_grades[i - 1]
        cur_score, cur_grade = scores_and_grades[i]
        assert cur_score <= prev_score
        assert grade_rank[cur_grade] >= grade_rank[prev_grade]
